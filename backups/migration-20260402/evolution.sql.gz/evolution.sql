--
-- PostgreSQL database dump
--

\restrict avnWOFyK4ySWeJH5T6M6O6eGVDXWKEP0HN8n8gzUhEShbVVUI2EEmb8CXPkJCfv

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg13+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict avnWOFyK4ySWeJH5T6M6O6eGVDXWKEP0HN8n8gzUhEShbVVUI2EEmb8CXPkJCfv

